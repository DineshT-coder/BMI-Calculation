# Bmi calculator helps us to monitor health condition and diet plan
![Bmi calculator](https://user-images.githubusercontent.com/109327528/215051631-10bf87bd-9e9c-4ef0-94de-4f781c92c3d5.png)
